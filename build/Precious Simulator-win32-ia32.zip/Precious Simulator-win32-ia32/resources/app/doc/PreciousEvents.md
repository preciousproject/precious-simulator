# Precious Events
Inherits from Event Emitter.  
Intended to be used as Singleton.  