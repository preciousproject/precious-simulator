"use strict";

module.exports =
{
    InternalError: -1,
    SingleGet: 0,
    ContinuousGet: 1,
    SinglePost: 2,
    UpdateRequest: 3,
    RemoveRequest: 4
};
