# Precious Simulator
## Installation
Run `npm install` after cloning repository.
### Required
Node.js >=v5.1.1  
grunt-cli

## Running
In root folder enter: `npm start`.
## Building
If app already compiled run `grunt electron`.  
For compiling and building run either `grunt` or `grunt build`.

	
### Notes
* To compile for Windows on Non-Windows hosts, wine is needed. [See here](https://github.com/maxogden/electron-packager#building-windows-apps-from-non-windows-platforms)
* Compiling for OSX on Windows isn't always working. [See here](https://github.com/maxogden/electron-packager/issues/96)