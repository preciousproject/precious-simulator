module.exports = {
    success: 0,
    error: 1,
    requestRejected: 2,
    unknown: 3
};